package interfaces;

public interface Environment {
	void extentRate();
	void toProtect();
}
