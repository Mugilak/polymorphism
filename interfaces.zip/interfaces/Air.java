package interfaces;

public class Air implements Pollution {
	public Air() {
		System.out.println("*** I am AIR POLLUTION ***");
	}

	public void reason() {
		System.out.println("--->>>  Vehicles and Manufactures are the reason for Air Pollution ");
//		System.out.println(Pollution.toReduce("Self-vehicles and Artificial Things"));
//		toProtect();
	}

	public void toProtect() { // overridden of default method in pollution
		System.out.println("\nProtect By-- Check daily air pollution forecasts in your area(from Air class).\n");
	}
	
	public void extentRate() { // overridden of abstracted method
		System.out.println("\n90% of air is polluted");
	}

	public static void main(String args[]) {
		Air air = new Air();
		air.extentRate();
		air.reason();
		System.out.println(Pollution.toReduce("Self-vehicles and Artificial Things"));
		air.toProtect();
		
		Environment env =new Air();
		env.extentRate();
		((Air) env).reason();
		((Air) env).toProtect();
	}
}