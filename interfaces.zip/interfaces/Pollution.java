package interfaces;

public interface Pollution extends Environment{
	public void reason();
	void extentRate();
	static String toReduce(String msg) {
		return "reduce - "+msg;
	}
	default void toProtect() {
//		reason();
//		System.out.println(toReduce("Self-vehicles and Artificial Things"));
		extentRate();
		System.out.println("\n to Protect --- Create Awareness !\n");
	}
}
