package methodOverriding;

public class overidingMain {

	
	public static void main(String[] args) {
		
		Dog dog1 = new Dog ();
		dog1.speak();
		
		Dog dog2 = new Puppy ();
		dog2.speak();
		
//		Dog dog = new Puppy ();
////		dog.bark();
//		((Puppy) dog).bark();
		
//		Dog dog2 =new Dog();         // ClassCastException
//		((Puppy) dog2).bark();
//		
//		Dog dog3 =new Dog();
//		Puppy puppy = (Puppy)dog3;
//		puppy.bark();
		
//		Puppy p = new Puppy();
////		p.speak();
//		p.bark();
//		p.eat();
//		p.smell();
//		p.walk();
	}

}
