package methodOverriding;

public class Puppy extends Dog {
	public void bark() {
//		super.speak();
		System.out.println("\nPUPPY --- wow-wow");
	}

	public void eat() { // NOT a overridden method... this will be considered as puppy's method
		System.out.println("PUPPY --- chew");
	}

//	void smell() {     // error FINAL METHODS ARE NOT OVERRIDDEN
//		System.out.println("PUPPY --- Smell");
//	}

	protected void walk() {
		System.out.println("PUPPY --- Walk");
	}

}
