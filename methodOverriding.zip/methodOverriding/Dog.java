package methodOverriding;

public class Dog {
	public void speak() {
		bark();
		System.out.println("DOG --- wow-wow-wow-wow");
	}

	public void bark() {
		System.out.println("\nDOG --- wow-wow-wow-wow");
	}

//	private void eat() {
//		System.out.println("DOG --- chew");
//	}

	final void smell() {
		System.out.println("DOG --- Smell");
	}

	protected void walk() {
		System.out.println("DOG --- Walk");
	}
}
