package Assignment;

public class Assignmentmain {
	public static void main(String[] args) {
		parent parent1 = new parent();
		parent1.print();
		
		parent parent2 = new child();
		((child)parent2).println();
		
		parentAbstract parent3 = new AbstractChild(); 
		parent3.print();
		
	}
}
