package Assignment;

public class child extends parent {
	public void println() {
		System.out.println("Iam println from child !!!");
	}
}
