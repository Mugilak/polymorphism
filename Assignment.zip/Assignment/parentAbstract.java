package Assignment;

public abstract class parentAbstract {
	public void print() {
		println();
		System.out.println("I am print from parent");
	}
	abstract void println();
	
}
