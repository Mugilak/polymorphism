package Assignment;

public class parent {
	public void print() {
		System.out.println("I am print from parent !!!");
	}
}
