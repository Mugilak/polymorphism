package methodOveroading;

public class methodOverloadMain {

	public static void main(String[] args) {
		methodOverload overload = new methodOverload();         
		overload.a(5l, 6l);           // long
		overload.a(8, 4);             //int
		overload.a('g', 'h');         //int     //private overloaded methods are accesed in same class(where it is declared) only
		overload.a("Hello", "Mugi");   //String
		overload.a(237.5f, 88.5f);     //double  //private static overloaded method
		overload.a(5353.74, 664656.646);   //double
		overload.a(1, "hi");           //protected passed
		overload.a(4, 5.65);           // double
	}

}
