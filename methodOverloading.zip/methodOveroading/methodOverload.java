package methodOveroading;

public class methodOverload {

	public void a(long x, long y) {
		System.out.println("long static method called");
	}

	public static void a(int x, int y) {
		System.out.println("int method called");
	}

	private void a(char x, char y) { // private accessed within this clas only
		System.out.println("char method");
	}

	final void a(String x, String y) {
		System.out.println("String");
	}
	final void a(String x, int y) {
		System.out.println("String");
	}

	private static void a(float x, float y) {
		System.out.println("float");
	}

	void a(double x, double y) {
		System.out.println("double");
	}
	protected void a(int x, String y) {
		System.out.println("Protected  -- int ,double");
	}
}
