package methodOveroading;

public class constructorOverloading {
	constructorOverloading(){
		System.out.println("Constructor without parameter");
	}
}
